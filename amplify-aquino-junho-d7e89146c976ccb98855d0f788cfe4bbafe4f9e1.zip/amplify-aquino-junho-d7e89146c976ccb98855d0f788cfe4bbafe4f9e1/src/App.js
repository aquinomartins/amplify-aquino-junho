import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1>Jesus Cristo_O Caminho, A Verdade e A Vida</h1>
        <h3>Hello from V2</h3>
      </header>
    </div>
  );
}

export default App;